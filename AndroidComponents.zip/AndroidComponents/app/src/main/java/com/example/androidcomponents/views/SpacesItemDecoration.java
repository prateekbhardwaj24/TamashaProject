package com.example.androidcomponents.views;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class SpacesItemDecoration extends RecyclerView.ItemDecoration {
    private int space;
    private int spacing;
    private int displayMode;
    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;
    public static final int GRID = 2;
    public static final int GRID_HORIZONTAL = 7;
    public static final int TOP_N_BOTTOM = 3;
    public static final int ONLY_TOP = 4;
    public static final int ONLY_TOP_RIGHT = 5;
    public static final int VARIABLE_SPACING = 6;
    public static final int STAGGERED_VERTICAL = 8;
    private int startSpacing = 0;
    private int endSpacing = 0;
    private boolean showStart = true;
    private boolean showEnd = true;
    private int spanCount = 0;
    private boolean includeEdge = false;

    public SpacesItemDecoration(int spacing, int displayMode, boolean showStart, boolean
            showEnd) {
        this.spacing = spacing;
        this.startSpacing = spacing;
        this.endSpacing = spacing;
        this.displayMode = displayMode;
        this.showStart = showStart;
        this.showEnd = showEnd;
    }


    public SpacesItemDecoration(int spanCount, int spacing,int displayMode, boolean includeEdge) {
        this.spanCount = spanCount;
        this.spacing = spacing;
        this.includeEdge = includeEdge;
        this.displayMode = displayMode;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
      //  int position = parent.getChildAdapterPosition(view); // item position
       // int column = position % spanCount; // item column

        int position = parent.getChildViewHolder(view).getAdapterPosition();
        int itemCount = state.getItemCount();

        RecyclerView.LayoutManager layoutManager = parent.getLayoutManager();

        setSpacingForDirection(outRect, layoutManager, position, itemCount, parent);

//        if (includeEdge) {
//            outRect.left = spacing - column * spacing / spanCount; // spacing - column * ((1f / spanCount) * spacing)
//            outRect.right = (column + 1) * spacing / spanCount; // (column + 1) * ((1f / spanCount) * spacing)
//
//            if (position < spanCount) { // top edge
//            }
//            outRect.top = spacing;
//            outRect.bottom = spacing; // item bottom
//        } else {
//            outRect.left = column * spacing / spanCount; // column * ((1f / spanCount) * spacing)
//            outRect.right = spacing - (column + 1) * spacing / spanCount; // spacing - (column + 1) * ((1f /    spanCount) * spacing)
//            if (position >= spanCount) {
//                outRect.top = spacing; // item top
//            }
//        }
    }

    private void setSpacingForDirection(Rect outRect, RecyclerView.LayoutManager layoutManager, int position, int itemCount, RecyclerView parent) {
        if (displayMode == -1) {
            displayMode = resolveDisplayMode(layoutManager);
        }

        switch (displayMode){
            case HORIZONTAL:
                outRect.left = (showStart && position == 0) ? startSpacing : ((position > 0) ? spacing : 0);
                outRect.right = (showEnd && position == itemCount - 1) ? endSpacing : ((position == itemCount - 1) ? spacing : 0);
                outRect.top = spacing;
                Log.d("spaceing:","ho "+spacing);
                outRect.bottom = spacing;
                break;
            case VERTICAL:
                outRect.left = 0;
                outRect.right = 0;
                Log.d("spaceing:","ver "+spacing);
                outRect.top = (showStart && position == 0) ? startSpacing : ((position > 0) ? spacing : 0);
                outRect.bottom = (showEnd && position == itemCount - 1) ? endSpacing : ((position == itemCount - 1) ? spacing : 0);
                break;
            case GRID:
                if (layoutManager instanceof GridLayoutManager) {
                    GridLayoutManager gridLayoutManager = (GridLayoutManager) layoutManager;
                    int cols = gridLayoutManager.getSpanCount();
                    int rows = (itemCount / cols) + (itemCount % cols > 0 ? 1 : 0);

                    //TODO need to re-write its logic
                    Log.d("spaceing:"," "+spacing);

                    outRect.left = spacing;
                    outRect.right = position % cols == cols - 1 ? spacing : 0;
                    outRect.top = spacing;
                    outRect.bottom = position / cols == rows - 1 ? spacing : 0;
                }
                break;
        }

    }

    private int resolveDisplayMode(RecyclerView.LayoutManager layoutManager) {
        if (layoutManager instanceof GridLayoutManager) {
            Log.d("spaceing:","display grid");
            return GRID;
        }
        if (layoutManager.canScrollHorizontally()) return HORIZONTAL;
        return VERTICAL;
    }
}
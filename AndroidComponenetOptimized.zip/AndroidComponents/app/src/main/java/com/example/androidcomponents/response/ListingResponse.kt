package com.example.androidcomponents.response

import com.android.volley.VolleyError
import com.example.androidcomponents.database.model.FoodHorizontalModel
import com.example.androidcomponents.database.model.FoodImageListModel
import com.example.androidcomponents.database.model.FoodListModel
import com.example.androidcomponents.database.model.FoodModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject

class ListingResponse : BaseResponse {
    private var foodList:MutableList<FoodModel>? = null
    private var exploreList: MutableList<FoodListModel>? = null
    private var exploreHorizontalList: MutableList<FoodHorizontalModel>? = null
    private var exploreImageList: MutableList<FoodImageListModel>? = null

    constructor(response: JSONObject?) : super(response) {
        getData()
    }

    constructor(error: VolleyError?) : super(error)

    private fun getData() {
        try {
            val itemArray = getResponse()?.optJSONObject("data")?.optJSONArray("verticalList")
            val foodItemArray = getResponse()?.optJSONObject("data")
            val itemArray2 = getResponse()?.optJSONObject("data")?.optJSONArray("horiList")
            val itemArray3 = getResponse()?.optJSONObject("data")?.optJSONArray("imageList")
            exploreList = Gson().fromJson<ArrayList<FoodListModel>>(
                itemArray.toString(),
                object : TypeToken<ArrayList<FoodListModel>?>() {}.type
            )
            exploreHorizontalList = Gson().fromJson<ArrayList<FoodHorizontalModel>>(
                itemArray2.toString(),
                object : TypeToken<ArrayList<FoodHorizontalModel>?>() {}.type
            )
            exploreImageList = Gson().fromJson<ArrayList<FoodImageListModel>>(
                itemArray3.toString(),
                object : TypeToken<ArrayList<FoodImageListModel>?>() {}.type
            )

            foodList = Gson().fromJson<ArrayList<FoodModel>>(foodItemArray.toString(), object : TypeToken<ArrayList<FoodModel>?>() {}.type)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getHorizontalList(): MutableList<FoodHorizontalModel> {
        if (exploreHorizontalList == null)
            exploreHorizontalList = ArrayList()

        return exploreHorizontalList!!
    }

    fun getImageList(): MutableList<FoodImageListModel> {
        if (exploreImageList == null)
            exploreImageList = ArrayList()

        return exploreImageList!!
    }

    fun getList(): MutableList<FoodListModel> {
        if (exploreList == null)
            exploreList = ArrayList()

        return exploreList!!
    }
    fun getFinalList():MutableList<FoodModel>{
        if (foodList == null)
            foodList =ArrayList()

        return foodList!!
    }

}
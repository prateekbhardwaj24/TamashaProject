package com.example.androidcomponents.ui

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidcomponents.R
import com.example.androidcomponents.database.db.DataBaseHelper
import com.example.androidcomponents.database.model.MainViewModelFactory
import com.example.androidcomponents.database.model.Post
import com.example.androidcomponents.databinding.ActivityMainBinding
import com.example.androidcomponents.ui.adapter.PostAdapter
import com.example.androidcomponents.viewmodel.MainViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity(), Observer<List<Post>> {
    private lateinit var mBinding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var factory: MainViewModelFactory
    private lateinit var dbHelper: DataBaseHelper
    private lateinit var postAdapter: PostAdapter
    private var imageUri: String = ""
    private val DEFAULT_IMAGE = R.drawable.ic_image_select
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityMainBinding.inflate(layoutInflater)
        factory = MainViewModelFactory(this)
        viewModel = ViewModelProvider(this, factory).get(MainViewModel::class.java)
        mBinding = DataBindingUtil.setContentView(
            this,
            com.example.androidcomponents.R.layout.activity_main
        )
        chooseImage()
        mBinding.submitBtn.setOnClickListener {
            finaliser()
        }
        lifecycleScope.launch {
            getAllPost()
        }
    }


    private fun finaliser() {
        if (mBinding.thoughtEd.text.toString().isNotEmpty()) {
            uploadData(mBinding.thoughtEd.text.toString(), imageUri)
        } else {
            mBinding.thoughtEd.error = "Please enter thought"
        }
    }

    private fun uploadData(thought: String, imageUri: String) {
        CoroutineScope(Dispatchers.Main).launch {
            val res = viewModel.upLoadData(thought, imageUri)
            if (res > 0) {
                releaseiews()
                Toast.makeText(this@MainActivity, "Congratulations!!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@MainActivity, "Try again!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun releaseiews() {
        mBinding.thoughtEd.text.clear()
        mBinding.chooseIamge.setImageResource(
            DEFAULT_IMAGE
        )
    }

    private suspend fun getAllPost() {
        viewModel.getAllPost().observe(this, this)
    }

    private fun chooseImage() {
        mBinding.chooseIamge.setOnClickListener {
            mGetContent.launch("image/*")
        }
    }

    private var mGetContent = registerForActivityResult(GetContent(), ActivityResultCallback {
        imageUri = it.toString()
        Glide.with(this).load(it).into(mBinding.chooseIamge)
    })

    override fun onChanged(list: List<Post>?) {
        postAdapter = PostAdapter(list, this)
        postAdapter.notifyDataSetChanged()
        mBinding.recyclerView.layoutManager = LinearLayoutManager(this)
        mBinding.recyclerView.adapter = postAdapter
    }
}
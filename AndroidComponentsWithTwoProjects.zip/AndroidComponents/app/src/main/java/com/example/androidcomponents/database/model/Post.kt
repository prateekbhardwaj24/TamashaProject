package com.example.androidcomponents.database.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "post_table")
data class Post(
    @ColumnInfo(name = "thoght") val thought: String,
    @ColumnInfo(name = "uri") val imageUri: String,
    @PrimaryKey(autoGenerate = true) val id: Int? = null
)
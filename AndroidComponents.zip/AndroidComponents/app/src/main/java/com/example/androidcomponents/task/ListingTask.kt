package com.example.androidcomponents.task

import android.content.Context
import android.text.TextUtils
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.android.volley.*
import com.android.volley.toolbox.Volley
import com.example.androidcomponents.network.Network
import com.example.androidcomponents.response.AppRequest
import com.example.androidcomponents.response.ListingResponse
import org.json.JSONObject

class ListingTask(private val context: Context) : Response.Listener<JSONObject?>,
    Response.ErrorListener {
    //   private var mIsNetworkCallRunning = false
    private var mMediatorLiveData: MutableLiveData<Any>? = null

    @Throws(Exception::class)
    fun call(): MutableLiveData<Any>? {
        mMediatorLiveData = MutableLiveData<Any>()
//        if (mIsNetworkCallRunning) return mMediatorLiveData
//        mIsNetworkCallRunning = true
        // var url = "https://script.google.com/macros/s/AKfycbxrKBOCj-Kz8QJz4p_Jvnx6HJeKYrYXvAmMbqqDeGRuKwA-UaZYWhMUZpD6BlbWw8Rd2A/exec"
        // var url = "https://script.google.com/macros/s/AKfycbwWthS8yJXSLSAZpojYfO2ZdQGlh15iKjENejh_PcoVtT1tcN794Brz4mYO6w4KB3GihQ/exec"
        var url =
"https://script.google.com/macros/s/AKfycbxHC3LR-F8-hwQIUUNkGZdyBAzIy81DF_DCMj4L--9qOF1p_omzLmDu0_Dze07ejjyyBw/exec"
        Log.d("shaker: ", "-> url= ${url}")
        //  val request = EazyDinerRequest(Request.Method.GET, url, this, this)
        val request = AppRequest(Request.Method.GET, url, this, this)

        Volley.newRequestQueue(context.applicationContext).add(request)
        Network().getGeneralRequestQueue()?.add(request)
        return mMediatorLiveData
    }


    @Override
    override fun onErrorResponse(error: VolleyError?) {
        ////   mIsNetworkCallRunning = false
//        AppLog.showError(javaClass.simpleName, error!!.localizedMessage)
        // Log.d("shaker: ","-> error= ${error}")
        mMediatorLiveData!!.postValue(ListingResponse(error))

    }

    @Override
    override fun onResponse(response: JSONObject?) {
        // mIsNetworkCallRunning = false
        // AppLog.showInfo(javaClass.simpleName, response.toString())
        Log.d("shaker: ", "-> res= ${response}")
        mMediatorLiveData!!.postValue(ListingResponse(response))
    }
}
package com.example.androidcomponents.database.db
import androidx.lifecycle.LiveData
import com.example.androidcomponents.database.model.Post


class DbHelperImpl(private val dataBase: DataBase):DataBaseHelper  {

    //
//    override suspend fun insert(post: Post): LiveData<Long> {
//        return dataSource.uploadDao().insert(post)
//    }
//
//    override suspend fun update(post: Post) {
//        return dataSource.uploadDao().update(post)
//    }
//
//    override suspend fun delete(post: Post) {
//        return dataSource.uploadDao().delete(post)
//    }
//
//    override suspend fun deleteAllNotes() {
//       return dataSource.uploadDao().deleteAllNotes()
//    }
//
//    override suspend fun getAllNotes(): LiveData<List<Post>> {
//        return dataSource.uploadDao().getAllNotes()
//    }
    override suspend fun getAllPost(): LiveData<List<Post>> {
        return dataBase.uploadDao().getAllNotes()
    }

    override suspend fun insertPost(users: Post): Long {
        return dataBase.uploadDao().insert(users)
    }
}
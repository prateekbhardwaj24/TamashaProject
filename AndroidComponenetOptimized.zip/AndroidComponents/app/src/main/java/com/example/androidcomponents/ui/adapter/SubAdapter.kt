package com.example.androidcomponents.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

import com.example.androidcomponents.database.model.FoodListModel
import com.example.androidcomponents.database.model.FoodModel
import com.example.androidcomponents.databinding.RvItemFoodListBinding
import com.example.androidcomponents.databinding.RvItemGridViewBinding
import com.example.androidcomponents.databinding.RvItemImageListBinding
import com.example.androidcomponents.utils.Dimension

class SubAdapter(
    imageList: ArrayList<FoodModel.FoodGridListModel>,
    data: FoodModel,
    context: Context
) :RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private val imageList: ArrayList<FoodModel.FoodImageListModel> by lazy { ArrayList<FoodModel.FoodImageListModel>() }
    private val verticalList: ArrayList<FoodModel> by lazy { ArrayList<FoodModel>() }
    private val gridList: ArrayList<FoodModel.FoodGridListModel> by lazy { ArrayList<FoodModel.FoodGridListModel>() }
    private val grid: Int = 0
    private val slider: Int = 1
    private val list: Int = 2

//    constructor(list: ArrayList<out Any>, data: FoodListModel) : this(data) {
//        if (list[0] is FoodListModel.FoodImageListModel)
//            imageList.addAll(list as ArrayList<FoodListModel.FoodImageListModel>)
//        else if (list[0] is FoodListModel.FoodGridListModel)
//            gridList.addAll(list as ArrayList<FoodListModel.FoodGridListModel>)
//        else if (list[0] is FoodListModel)
//            verticalList.addAll(list as ArrayList<FoodListModel>)
//    }
    override fun getItemViewType(position: Int): Int {
        return when {
            "grid".equals(data.foodLayout, true) ->
                grid
            "x-list".equals(data.foodLayout, true) ->
                slider
            else -> list
        }

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return when (viewType) {
            grid ->
                GridViewHolder(RvItemGridViewBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            slider ->
                SliderViewHolder(RvItemImageListBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            else ->
                ListViewHolder(
                    RvItemFoodListBinding.inflate(
                        LayoutInflater.from(parent.context),
                        parent,
                        false
                    )
                )
        }
    }
    class ListViewHolder(var binding: RvItemFoodListBinding) :RecyclerView.ViewHolder(binding.root) {
        fun bind(data: FoodListModel, context: Context) {

            binding.foodImage.layoutParams.height = Dimension.convertDpToPixels(190f,context)
            binding.foodDesc.text = data.foodDesc
            binding.foodPrice.text = data.foodPrice
            binding.foodRating.text = data.foodRating
            binding.foodName.text = data.foodName
            if (data.foodExtendedOffer.isEmpty()) {
                binding.foodExtendedOffer.visibility = View.GONE
                binding.seperator.visibility = View.GONE
            } else {
                binding.foodExtendedOffer.visibility = View.VISIBLE
                binding.seperator.visibility = View.VISIBLE
                binding.foodExtendedOffer.text = data.foodExtendedOffer
            }

            binding.foodOffer.text =
                HtmlCompat.fromHtml(data.foodOffer, HtmlCompat.FROM_HTML_MODE_COMPACT)
            Glide.with(context).asBitmap().load(data.foodImage).into(binding.foodImage)
        }
    }
    class GridViewHolder(val binding: RvItemGridViewBinding):RecyclerView.ViewHolder(binding.root) {
        fun bind(data: FoodModel.FoodGridListModel, context: Context) {
            //  val width = (Dimension.getDisplaySize(context).widthPixels * .16).toInt()
            val height = (Dimension.getDisplaySize(context).heightPixels * .18).toInt()

            //  binding.foodImage.layoutParams.width = width
            binding.foodImage.layoutParams.height = height
            binding.foodImage.scaleType = ImageView.ScaleType.CENTER_CROP
            binding.foodName.text = data.foodName
            Glide.with(context).asBitmap().load(data.foodImage).into(binding.foodImage)
        }

    }
    class SliderViewHolder(var binding: RvItemImageListBinding):RecyclerView.ViewHolder(binding.root) {
        fun bind(foodImageListModel: FoodListModel.FoodImageListModel) {
            val width = (Dimension.getDisplaySize(context).widthPixels * .20).toInt()
            val height = (Dimension.getDisplaySize(context).heightPixels * .10).toInt()

            binding.image.layoutParams.width = width
            binding.image.layoutParams.height = height
            Glide.with(context).asBitmap().load(data.foodImage).into(binding.image)
            binding.name.text = data.foodName
        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is GridViewHolder -> holder.bind(gridList[position],context)
            is SliderViewHolder -> holder.bind(imageList[position])
            is ListViewHolder -> holder.bind(verticalList[position])
        }
    }

    override fun getItemCount(): Int {
        return when {
            imageList.size > 0 -> {
                    imageList.size
            }
            gridList.size > 0 -> gridList.size
            verticalList.size > 0 -> verticalList.size
            else -> 0
        }
    }
}
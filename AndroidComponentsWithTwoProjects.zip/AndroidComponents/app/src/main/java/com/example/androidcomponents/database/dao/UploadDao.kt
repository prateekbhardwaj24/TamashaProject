package com.example.androidcomponents.database.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.androidcomponents.database.model.Post

@Dao
interface UploadDao {
    @Insert
    suspend fun insert(post: Post):Long

    @Update
    suspend fun update(post: Post)

    @Delete
    suspend fun delete(post: Post)

    @Query("delete from post_table")
    suspend fun deleteAllNotes()

    @Query("select * from post_table order by id desc")
     fun getAllNotes(): LiveData<List<Post>>
}



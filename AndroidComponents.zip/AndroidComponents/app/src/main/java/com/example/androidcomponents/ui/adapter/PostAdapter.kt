package com.example.androidcomponents.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidcomponents.database.model.Post
import com.example.androidcomponents.databinding.RvItemViewBinding
import com.example.androidcomponents.ui.MainActivity


class PostAdapter(private val postList: List<Post>?, private val mainActivity: MainActivity): RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    class PostViewHolder( val binding: RvItemViewBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(post: Post, context: MainActivity) {
          binding.thoughtTxt.text = post.thought
            Glide.with(context.applicationContext).asBitmap().load(post.imageUri).into(binding.profileImage)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val binding =DataBindingUtil.inflate<RvItemViewBinding>(LayoutInflater.from(parent.context),com.example.androidcomponents.R.layout.rv_item_view,parent,false)
        return PostViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
     holder.bind(postList!![position],mainActivity)

    }

    override fun getItemCount(): Int {
        return postList!!.size
    }

}
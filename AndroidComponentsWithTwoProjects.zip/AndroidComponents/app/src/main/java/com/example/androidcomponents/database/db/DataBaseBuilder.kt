package com.example.androidcomponents.database.db


import android.content.Context
import androidx.room.Room


object DataBaseBuilder {
    private var INSTANCE: DataBase? = null
    fun getInstance(context: Context): DataBase {
        if (INSTANCE == null) {
            synchronized(DataBase::class) {
                INSTANCE = buildRoomDB(context)
            }
        }
        return INSTANCE!!
    }
    private fun buildRoomDB(context: Context): DataBase {
       return Room.databaseBuilder(
            context.applicationContext,
            DataBase::class.java,
            "practice"
        ).build()
    }

}


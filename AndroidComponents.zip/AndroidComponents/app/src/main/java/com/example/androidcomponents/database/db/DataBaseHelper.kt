package com.example.androidcomponents.database.db

import androidx.lifecycle.LiveData
import com.example.androidcomponents.database.model.Post

interface DataBaseHelper {
    suspend fun getAllPost(): LiveData<List<Post>>

    suspend fun insertPost(users: Post):Long
}
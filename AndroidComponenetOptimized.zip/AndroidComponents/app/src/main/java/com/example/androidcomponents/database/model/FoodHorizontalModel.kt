package com.example.androidcomponents.database.model

data class FoodHorizontalModel(
    var foodName: String,
    var foodImage: String
)
//data class FoodImageListModel(
//    var foodImage: String,
//    var foodName:String
//)
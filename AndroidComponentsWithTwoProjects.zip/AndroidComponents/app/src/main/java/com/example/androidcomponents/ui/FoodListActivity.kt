package com.example.androidcomponents.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.androidcomponents.database.model.MainViewModelFactory
import com.example.androidcomponents.databinding.ActivityFoodListBinding
import com.example.androidcomponents.response.ListingResponse
import com.example.androidcomponents.ui.adapter.FoodListAdapter
import com.example.androidcomponents.utils.Dimension
import com.example.androidcomponents.viewmodel.FoodListViewModel
import com.example.androidcomponents.views.SpacesItemDecoration
import com.facebook.shimmer.ShimmerFrameLayout


class FoodListActivity : AppCompatActivity(), Observer<Any>{
    private lateinit var mBinding: ActivityFoodListBinding
    private lateinit var viewModel: FoodListViewModel
    private lateinit var factory: MainViewModelFactory
    private lateinit var mdapter:FoodListAdapter
    private lateinit var mLayoutManager:RecyclerView.LayoutManager
    private lateinit var mShimmerViewContainer: ShimmerFrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
     //   mBinding = ActivityFoodListBinding.inflate(layoutInflater)
        factory = MainViewModelFactory(this)
        viewModel = ViewModelProvider(this, factory)[FoodListViewModel::class.java]
        viewModel.getListings()?.observe(this, this)

        mBinding = DataBindingUtil.setContentView(
            this,
            com.example.androidcomponents.R.layout.activity_food_list
        )

        mLayoutManager = LinearLayoutManager(this)
        mBinding.listRv.layoutManager = mLayoutManager
        val decoration = SpacesItemDecoration(2,
            Dimension.convertDpToPixels(8f, mBinding.root.context),
            LinearLayoutManager.VERTICAL, true)
        mBinding.listRv.addItemDecoration(decoration)
        mBinding.listRv.setHasFixedSize(false)
        mdapter = FoodListAdapter(null,this)
        mBinding.listRv.adapter = mdapter
    }

    override fun onPause() {
        super.onPause()
        mBinding.shimmerViewContainer.stopShimmerAnimation()
    }

    override fun onResume() {
        super.onResume()
        mBinding.shimmerViewContainer.startShimmerAnimation()
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onChanged(t: Any?) {
      if (t is ListingResponse){
          mBinding.shimmerViewContainer.stopShimmerAnimation()
          mBinding.shimmerViewContainer.visibility = View.GONE
          Log.d("shaker1: ","-> t= ${t.getList().size}, ${t.getHorizontalList().size}")
          mdapter.updateList(t.getList(),t.getHorizontalList(),t.getImageList())
          mdapter.notifyDataSetChanged()
      }
    }
}
package com.example.androidcomponents.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidcomponents.database.model.FoodHorizontalModel
import com.example.androidcomponents.databinding.RvItemGridViewBinding
import com.example.androidcomponents.utils.Dimension

class HorizontalAdapter(private var list: List<FoodHorizontalModel>, private val context: Context):RecyclerView.Adapter<HorizontalAdapter.ViewHolder>() {
    class ViewHolder(val binding: RvItemGridViewBinding):RecyclerView.ViewHolder(binding.root) {
        fun bind(data: FoodHorizontalModel, context: Context) {
          //  val width = (Dimension.getDisplaySize(context).widthPixels * .16).toInt()
            val height = (Dimension.getDisplaySize(context).heightPixels * .18).toInt()

          //  binding.foodImage.layoutParams.width = width
            binding.foodImage.layoutParams.height = height
            binding.foodImage.scaleType = ImageView.ScaleType.CENTER_CROP
            binding.foodName.text = data.foodName
            Glide.with(context).asBitmap().load(data.foodImage).into(binding.foodImage)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
       return ViewHolder(RvItemGridViewBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list!![position],context)
    }

    override fun getItemCount(): Int {
        return list.size ?:0
    }
}
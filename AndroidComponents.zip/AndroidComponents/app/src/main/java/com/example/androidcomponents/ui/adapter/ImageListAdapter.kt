package com.example.androidcomponents.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidcomponents.database.model.FoodImageListModel
import com.example.androidcomponents.databinding.RvItemImageListBinding
import com.example.androidcomponents.utils.Dimension

class ImageListAdapter(private val list: MutableList<FoodImageListModel>,private val context: Context) :RecyclerView.Adapter<ImageListAdapter.ViewHolder>(){
    class ViewHolder(var binding:RvItemImageListBinding):RecyclerView.ViewHolder(binding.root) {
        fun bind(data: FoodImageListModel, context: Context) {
            binding.image.layoutParams.width = Dimension.convertDpToPixels(70f,context)
            binding.image.layoutParams.height = Dimension.convertDpToPixels(70f,context)
            Glide.with(context).asBitmap().load(data.foodImage).into(binding.image)
            binding.name.text = data.foodName
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            RvItemImageListBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position],context)
    }

    override fun getItemCount(): Int {
        return list.size ?:0
    }
}
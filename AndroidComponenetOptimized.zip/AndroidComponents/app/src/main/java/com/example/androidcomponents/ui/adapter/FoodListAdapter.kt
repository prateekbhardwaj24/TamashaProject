package com.example.androidcomponents.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidcomponents.database.model.FoodHorizontalModel
import com.example.androidcomponents.database.model.FoodImageListModel
import com.example.androidcomponents.database.model.FoodModel
import com.example.androidcomponents.databinding.RvImageListingBinding
import com.example.androidcomponents.databinding.RvItemFoodListBinding
import com.example.androidcomponents.databinding.RvItemXLayoutBinding
import com.example.androidcomponents.utils.Dimension
import com.example.androidcomponents.views.SpacesItemDecoration


    class FoodListAdapter(private var list: MutableList<FoodModel>?, private val context: Context) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
//    private var horiZontalList: MutableList<FoodHorizontalModel> = ArrayList()
//    private var imageList: MutableList<FoodImageListModel> = ArrayList()
    private var foodList: MutableList<FoodModel> = ArrayList()
    private var listener: OnClickListener? = null

    companion object {
        const val IMAGE = 1
        const val HORIZONTAL_SLIDER = 2
        const val VERTICAL_SLIDER = 3
    }

    override fun getItemViewType(position: Int): Int {
        return when (list!![position].fo) {
            "image" -> IMAGE
            "x_slider" -> HORIZONTAL_SLIDER
            else -> VERTICAL_SLIDER
        }
    }

    fun updateList(
        list: List<Any>,
        horizontalList: MutableList<FoodHorizontalModel>,
        imageList: MutableList<Any>,
        finalList: MutableList<FoodModel>
    ) {
        if (this.list == null)
            this.list = ArrayList()

        val initialPosition = this.list!!.size
        this.list?.addAll(list)
        this.horiZontalList.addAll(horizontalList)
        this.imageList.addAll(imageList)
        this.foodList = finalList
        notifyItemRangeChanged(initialPosition, initialPosition + list.size)
    }

    class MyVerticalViewHolder(var binding: RvItemFoodListBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(foodModel: FoodModel, context: Context) {
//
//            val decoration = SpacesItemDecoration(
//                Dimension.convertDpToPixels(8f, binding.root.context),
//                LinearLayoutManager.VERTICAL,
//                true,
//                true
//            )
//            if (binding..itemDecorationCount > 0)
//                binding.imageList.removeItemDecorationAt(0)
//
//            binding.imageList.addItemDecoration(
//                decoration
//            )
//            binding.imageList.layoutManager =
//                LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
//            adapter = ImageListAdapter(data, context)
//            binding.imageList.adapter = adapter
//
//
//            binding.foodImage.layoutParams.height = Dimension.convertDpToPixels(190f,context)
//            binding.foodDesc.text = data.foodDesc
//            binding.foodPrice.text = data.foodPrice
//            binding.foodRating.text = data.foodRating
//            binding.foodName.text = data.foodName
//            if (data.foodExtendedOffer.isEmpty()) {
//                binding.foodExtendedOffer.visibility = View.GONE
//                binding.seperator.visibility = View.GONE
//            } else {
//                binding.foodExtendedOffer.visibility = View.VISIBLE
//                binding.seperator.visibility = View.VISIBLE
//                binding.foodExtendedOffer.text = data.foodExtendedOffer
//            }
//
//            binding.foodOffer.text =
//                HtmlCompat.fromHtml(data.foodOffer, HtmlCompat.FROM_HTML_MODE_COMPACT)
//            Glide.with(context).asBitmap().load(data.foodImage).into(binding.foodImage)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            IMAGE -> MyImageViewHolder(
                RvImageListingBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )
            HORIZONTAL_SLIDER -> MyGridViewHolder(
                RvItemXLayoutBinding.inflate(
                    LayoutInflater.from(
                        parent.context
                    ), parent, false
                )
            )
            else -> MyVerticalViewHolder(
                RvItemFoodListBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )
        }
    }

    class MyImageViewHolder(var binding: RvImageListingBinding) :
        RecyclerView.ViewHolder(binding.root) {
        private lateinit var adapter: ImageListAdapter
        fun bind(
            data: FoodModel,
            context: Context,
            listener: OnClickListener?
        ) {
            if (data.imageList.size <= 0) {
                binding.imageList.visibility = View.GONE
            } else {
                val decoration = SpacesItemDecoration(
                    Dimension.convertDpToPixels(8f, binding.root.context),
                    LinearLayoutManager.HORIZONTAL,
                    true,
                    true
                )
                if (binding.imageList.itemDecorationCount > 0)
                    binding.imageList.removeItemDecorationAt(0)

                binding.imageList.addItemDecoration(
                    decoration
                )
                binding.imageList.layoutManager =
                    LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
               // adapter = SubAdapter(data.imageList,data, context)
                binding.imageList.adapter = SubAdapter(data.imageList,data, context)
                if (listener != null) {
                    adapter.setCLickListener(listener)
                }
            }
        }
    }

    class MyGridViewHolder(var binding: RvItemXLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {
        private lateinit var adapter: GridAdapter
        private val SPANCOUNT = 2
        fun bind(
            data: FoodModel,
            context: Context,
            holder: MyGridViewHolder,
            listener: OnClickListener?
        ) {

            if (data.gridList.size <= 0) {
                binding.horiList.visibility = View.GONE
            } else {
                if (binding.horiList.itemDecorationCount > 0)
                    binding.horiList.removeItemDecorationAt(0)

                binding.horiList.layoutManager = GridLayoutManager(context, SPANCOUNT)
                val decoration = SpacesItemDecoration(
                    Dimension.convertDpToPixels(8f, binding.root.context),
                    SpacesItemDecoration.GRID,
                    true
                )
                binding.horiList.addItemDecoration(decoration)
             //   adapter = GridAdapter(data, context)
                binding.horiList.adapter = SubAdapter(data.imageList,data, context)
                if (listener != null) {
                    adapter.setCLickListener(listener)
                }
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is MyImageViewHolder -> holder.bind(list!![position], context, listener)
            is MyVerticalViewHolder -> {
                holder.bind(list!![position], context)
//                holder.itemView.setOnClickListener {
//                    if (listener != null)
//                        listener!!.onItemClicked(list?.get(position)?.foodName)
//                }
            }
            is MyGridViewHolder -> holder.bind(list!![position], context, holder, listener)
        }
    }

    fun setCLickListener(listener: OnClickListener) {
        this.listener = listener
    }

    override fun getItemCount(): Int {
        return list?.size ?: 0
    }

    interface OnClickListener : GridAdapter.OnClickListener,
        ImageListAdapter.OnClickListener {
        override fun onItemClicked(name: String?)
    }
}
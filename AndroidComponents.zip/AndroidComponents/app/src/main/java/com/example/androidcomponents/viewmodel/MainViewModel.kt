package com.example.androidcomponents.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.androidcomponents.database.db.Repository
import com.example.androidcomponents.database.model.Post
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext

class MainViewModel(context: Context) : ViewModel() {
    private var repository = Repository(context)


     suspend fun upLoadData(thought: String, imageUri: String): Long {
      return CoroutineScope(Dispatchers.IO).async {
          repository.insert(Post(thought, imageUri))
      }.await()
    }

   suspend fun getAllPost(): LiveData<List<Post>> {
       return withContext(CoroutineScope(Dispatchers.IO).coroutineContext) {
           repository.getllPost()
       }
   }
}
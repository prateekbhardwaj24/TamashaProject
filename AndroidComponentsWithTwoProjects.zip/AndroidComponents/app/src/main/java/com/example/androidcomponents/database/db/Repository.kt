package com.example.androidcomponents.database.db

import android.content.Context
import androidx.lifecycle.LiveData
import com.example.androidcomponents.database.model.Post

class Repository(context: Context) {
    val dbHelper = DbHelperImpl(DataBaseBuilder.getInstance(context))

    suspend fun insert(post: Post): Long {
        return dbHelper.insertPost(post)
    }

    suspend fun getllPost(): LiveData<List<Post>> {
        return dbHelper.getAllPost()
    }



}
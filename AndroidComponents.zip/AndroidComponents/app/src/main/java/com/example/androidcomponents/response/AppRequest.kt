package com.example.androidcomponents.response

import com.android.volley.DefaultRetryPolicy
import com.android.volley.Response
import org.json.JSONObject

class AppRequest: CustomJsonRequest {

    constructor(
        method: Int,
        url: String?,
        listener: Response.Listener<JSONObject?>?,
        errorListener: Response.ErrorListener?) : super(method, url, listener, errorListener) {
    }
//    fun EazyDinerRequest(
//        method: Int,
//        url: String?,
//        listener: Response.Listener<JSONObject?>?,
//        errorListener: Response.ErrorListener?
//    ) {
//        super(method, url, listener, errorListener)
//        retryPolicy = DefaultRetryPolicy(EDUrl.LONG_TIMEOUT, EDUrl.DO_RETRY, EDUrl.BACKOFF)
//    }
}
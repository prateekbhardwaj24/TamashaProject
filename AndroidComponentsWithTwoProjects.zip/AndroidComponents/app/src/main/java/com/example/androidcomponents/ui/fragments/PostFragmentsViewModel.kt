package com.example.androidcomponents.ui.fragments

import androidx.lifecycle.ViewModel

class PostFragmentsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
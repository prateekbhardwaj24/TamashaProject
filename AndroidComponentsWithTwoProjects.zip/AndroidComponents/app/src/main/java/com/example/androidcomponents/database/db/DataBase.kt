package com.example.androidcomponents.database.db

import androidx.room.*
import com.example.androidcomponents.database.dao.UploadDao
import com.example.androidcomponents.database.model.Post

@Database(entities = [Post::class], version = 1)
abstract class DataBase: RoomDatabase() {
    abstract fun uploadDao(): UploadDao
}


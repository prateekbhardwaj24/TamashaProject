package com.example.androidcomponents.network

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import com.android.volley.*
import com.android.volley.toolbox.*
import java.io.File
import java.util.concurrent.Executors

open class Network {
    private val DEFAULT_CACHE_DIR = "FoodApp"
    private val DISK_CACHE_MAX_SIZE = 20 * 1024 * 1024
    private val LARGE_CACHE_DIR = "app-image-cache"
    private val LARGE_CACHE_SIZE = 50 * 1024 * 1024

    private var sDiskCache: DiskBasedCache? = null

    var sGeneralRequestQueue: RequestQueue? = null

    private var sSingleRequestQueue: RequestQueue? = null

    fun init(context: Context) {
        val cacheDir =
            File(context.cacheDir, DEFAULT_CACHE_DIR)
        sDiskCache = DiskBasedCache(cacheDir, DISK_CACHE_MAX_SIZE)
        val cacheDir2 =
            File(context.cacheDir, LARGE_CACHE_DIR)
        val sDiskCache2: Cache =
            DiskBasedCache(cacheDir2, LARGE_CACHE_SIZE)
        val delivery: ResponseDelivery = ExecutorDelivery(Executors.newFixedThreadPool(4))
        val singleDelivery: ResponseDelivery = ExecutorDelivery(Executors.newFixedThreadPool(1))
        sGeneralRequestQueue = RequestQueue(
            sDiskCache,
            BasicNetwork(HurlStack()),
            4,
            delivery
        )
        sGeneralRequestQueue!!.start()

        sSingleRequestQueue = RequestQueue(
            sDiskCache,
            BasicNetwork(HurlStack()),
            1,
            singleDelivery
        )
        sSingleRequestQueue!!.start()

//        sMainThreadRequestQueue = Volley.newRequestQueue(context);
//        var userAgent = "volley/0"
//        try {
//            val packageName = context.packageName
//            val info = context.packageManager.getPackageInfo(packageName, 0)
//            userAgent = packageName + "/" + info.versionCode
//        } catch (e: PackageManager.NameNotFoundException) {
//        }
//        val httpStack: HttpStack = OwnHttpClientStack(AndroidHttpClient.newInstance(userAgent))
//        sMainThreadRequestQueue =
//            Volley.newRequestQueue(context, httpStack)


    }

    fun getGeneralRequestQueue(): RequestQueue? {
        return sGeneralRequestQueue
    }


}
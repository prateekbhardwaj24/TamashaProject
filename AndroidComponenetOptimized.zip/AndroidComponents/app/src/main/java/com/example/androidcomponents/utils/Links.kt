package com.example.androidcomponents.utils

object Links {
    var DEFAULT_LIST_API =
        "https://script.google.com/macros/s/AKfycbxiHhZHYncdJdXdHfrO3bjYZg2DqzIEmdZ_tnnS5FE_dkG4NmiwXc3ju-Ca7ckUPAmFgA/exec"
    var LIST_API_PAGE_TWO =
        "https://script.google.com/macros/s/AKfycbz-QOYKNK8ur3Vgu0UmhpjZyfTyNEBlDvwCiRfuHxRupJtHCARwYElGx8B7Sxx3ypuXyw/exec"
}

package com.example.androidcomponents.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.androidcomponents.database.model.FoodHorizontalModel
import com.example.androidcomponents.database.model.FoodImageListModel
import com.example.androidcomponents.database.model.FoodListModel
import com.example.androidcomponents.databinding.RvImageListingBinding
import com.example.androidcomponents.databinding.RvItemFoodListBinding
import com.example.androidcomponents.databinding.RvItemXLayoutBinding
import com.example.androidcomponents.utils.Dimension
import com.example.androidcomponents.views.RvItemDecoration
import com.example.androidcomponents.views.SpacesItemDecoration

class FoodListAdapter(private var list:MutableList<FoodListModel>?, private val context: Context):RecyclerView.Adapter<RecyclerView.ViewHolder>() {
private  var horiZontalList: MutableList<FoodHorizontalModel> = ArrayList()
private  var imageList: MutableList<FoodImageListModel> = ArrayList()
    companion object {
        const val IMAGE = 1
        const val HORIZONTAL_SLIDER = 2
        const val VERTICAL_SLIDER = 3
    }

    override fun getItemViewType(position: Int): Int {
        return when (list!![position].foodLayout) {
            "image" -> IMAGE
            "x_slider" -> HORIZONTAL_SLIDER
            else -> VERTICAL_SLIDER
        }
    }
    fun updateList(
        list: List<FoodListModel>,
        horizontalList: MutableList<FoodHorizontalModel>,
        imageList: MutableList<FoodImageListModel>
    ){
        if (this.list==null)
            this.list = ArrayList()

        val initialPosition = this.list!!.size
        this.list?.addAll(list)
        this.horiZontalList.addAll(horizontalList)
        this.imageList.addAll(imageList)
        notifyItemRangeChanged(initialPosition, initialPosition + list.size)
    }

    class MyVerticalViewHolder(var binding: RvItemFoodListBinding):RecyclerView.ViewHolder(binding.root) {
        fun bind(data: FoodListModel, context: Context) {
            binding.foodDesc.text = data.foodDesc
            binding.foodPrice.text = data.foodPrice
            binding.foodRating.text = data.foodRating
            binding.foodName.text = data.foodName
            if (data.foodExtendedOffer.isEmpty()){
                binding.foodExtendedOffer.visibility = View.GONE
                binding.seperator.visibility = View.GONE
            }else{
                binding.foodExtendedOffer.visibility = View.VISIBLE
                binding.seperator.visibility = View.VISIBLE
                binding.foodExtendedOffer.text = data.foodExtendedOffer
            }
            binding.foodOffer.text = HtmlCompat.fromHtml(data.foodOffer, HtmlCompat.FROM_HTML_MODE_COMPACT)
            Glide.with(context).asBitmap().load(data.foodImage).into(binding.foodImage)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType){
            IMAGE -> MyImageViewHolder(RvImageListingBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            HORIZONTAL_SLIDER -> MyHorizontalViewHolder(RvItemXLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            else -> MyVerticalViewHolder(RvItemFoodListBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        }
    }
    class MyImageViewHolder(var binding: RvImageListingBinding):RecyclerView.ViewHolder(binding.root) {
        private lateinit var adapter:ImageListAdapter
        fun bind(data: MutableList<FoodImageListModel>, context: Context) {
            if (data.size<=0){
                binding.imageList.visibility = View.GONE
            }else{
                val tenDp = Dimension.convertDpToPixels(8f, binding.root.context)
                val fifteenDp = Dimension.convertDpToPixels(15f, binding.root.context)
                val trendsStartDp = (context.resources.displayMetrics.widthPixels * 0.46f).toInt()
                val decoration = SpacesItemDecoration(Dimension.convertDpToPixels(8f, binding.root.context), LinearLayoutManager.HORIZONTAL, true, true)
                val spanCount = 3 // 3 columns

                val spacing = Dimension.convertDpToPixels(12f, binding.root.context)

                val includeEdge = true

              //  binding.imageList.addItemDecoration(decoration)
                if (binding.imageList.itemDecorationCount > 0)
                    binding.imageList.removeItemDecorationAt(0)

                binding.imageList.addItemDecoration(
                    decoration
                )
                binding.imageList.layoutManager = LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false)
                adapter = ImageListAdapter(data,context)
                binding.imageList.adapter = adapter
            }
        }
    }
    class MyHorizontalViewHolder(var binding: RvItemXLayoutBinding):RecyclerView.ViewHolder(binding.root) {
        private lateinit var adapter: HorizontalAdapter
        fun bind(data: MutableList<FoodHorizontalModel>,context: Context) {

            if (data.size<=0){
                binding.horiList.visibility = View.GONE
            }else{
                binding.horiList.layoutManager = GridLayoutManager(context,2)
                val decoration = SpacesItemDecoration(2,Dimension.convertDpToPixels(8f, binding.root.context),SpacesItemDecoration.GRID, true)
                binding.horiList.addItemDecoration(decoration)
                adapter = HorizontalAdapter(data,context)
                binding.horiList.adapter = adapter
            }
        }
    }
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is MyImageViewHolder ->  holder.bind(imageList,context)
            is MyVerticalViewHolder ->  holder.bind(list!![position],context)
            is MyHorizontalViewHolder ->  holder.bind(horiZontalList,context)
        }
    }

    override fun getItemCount(): Int {
        return list?.size ?:0
    }
}